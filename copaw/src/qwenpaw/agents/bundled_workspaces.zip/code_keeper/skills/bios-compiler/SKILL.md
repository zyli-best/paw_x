---
name: bios-compiler
description: BIOS 代码编译。当用户要求编译 BIOS 代码、执行固件编译、运行编译脚本时触发。也适用于用户提供 buildId/biosVersion/projectFolder 等参数要求执行编译的场景，以及"帮我把代码编译一下"、"开始编译"这类模糊请求。当对话中出现"编译"、"build"、"固件"、"bios"关键词时，应考虑使用本 skill。
compatibility:
  - execute_shell_command
  - read_file
---

# BIOS 编译器 Skill

## 核心任务

**只做一件事：BIOS 代码编译。**

- 接收编译参数 → 验证目录 → 执行编译 → 读取结果 → 返回结论
- **编译失败绝不重试**，只返回失败原因
- 不做任何其他事情（不调试、不修改代码、不分析日志细节）

## 输入参数

调用方需提供以下三个参数，**按此顺序依次传入** `start.cmd`：

| 参数 | 类型 | 说明 |
|------|------|------|
| `buildId` | float | 编译的版本 ID（浮点数） |
| `biosVersion` | string | 编译的 BIOS 版本 |
| `projectFolder` | string | 项目文件夹路径 |

## 工作流程

### Step 1: 获取脚本路径

确定 `start.cmd` 的绝对路径。该脚本位于 skill 目录下的 `scripts/` 子目录中：

```
<skill_dir>/scripts/start.cmd
```

其中 `<skill_dir>` 是 `bios-compiler` skill 所在的目录（可在执行时通过 `glob_search` 或相对路径确定）。

### Step 2: 验证目录

检查 `projectFolder` 是否存在。若不存在，直接返回错误：
```
错误：项目目录不存在 — <projectFolder>
```

### Step 3: 执行编译

执行 `start.cmd`，传入三个参数：

```cmd
<skill_dir>\scripts\start.cmd <buildId> <biosVersion> <projectFolder>
```

其中 `start.cmd` 内部调用 `start.ps1` 并将三个参数依次传入。

**编译时长预估约 12 小时**，使用 `execute_shell_command` 时设置 `timeout` 为 `43200` 秒。

> ⚠️ **每次调用都是全新编译，直接执行即可**。不要检查本地是否已存在 `result.json`，更不要因为存在而跳过执行或询问用户。每次都正常启动编译，新结果会覆盖旧文件。

### Step 4: 读取结果

编译脚本执行完毕后，读取 `<skill_dir>\scripts\result.json` 文件（`start.cmd` 中的 `pushd %~dp0` 会将工作目录切到 `scripts/` 目录，生成的 `result.json` 也在该目录下），判断编译结果。

**result.json 字段说明：**

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | int | `0` 表示编译成功，非 `0` 表示编译失败 |
| `msg` | string | 编译结果描述（如 `"BUILD Fail!"` 或 `"BUILD Success!"`） |
| `log_file` | string | 编译日志文件路径（失败时可用于查看详细日志） |

### Step 4: 返回结论

**编译成功**（`code == 0`）— 简洁返回成功信息：
```
✅ 编译成功
BuildID: <buildId>
BIOS Version: <biosVersion>
```

**编译失败**（`code != 0`）— **直接返回失败原因，不重试**：
```
❌ 编译失败
BuildID: <buildId>
BIOS Version: <biosVersion>
失败原因: <msg 字段内容>
编译日志: <log_file 路径>
```

## ⚠️ 硬性规则

- **禁止重试**：编译失败时，直接输出失败原因并结束，不要自动重新编译
- **禁止越界**：不修改代码、不调试、不优化编译流程
- **禁止分析日志**：只从 `result.json` 中提取失败信息，不做深入分析
- **保持简洁**：输出结果要简短直接
- **私密保护**：绝不泄露私密信息；只操作 `projectFolder` 目录内的文件

## 示例

### 成功示例

输入参数：`buildId=1.0`, `biosVersion="V2.1.0"`, `projectFolder="D:\project\bios_code"`

执行命令：`<skill_dir>\scripts\start.cmd 1.0 V2.1.0 D:\project\bios_code`

`result.json` 内容：
```json
{
    "code": 0,
    "msg": "BUILD Success!",
    "log_file": "D:\\DevCoTools\\LfcBpr\\log.txt"
}
```

输出：
```
✅ 编译成功
BuildID: 1.0
BIOS Version: V2.1.0
```

### 失败示例

`result.json` 内容：
```json
{
    "code": 1,
    "msg": "BUILD Fail!",
    "log_file": "D:\\DevCoTools\\LfcBpr\\log.txt"
}
```

输出：
```
❌ 编译失败
BuildID: 1.0
BIOS Version: V2.1.0
失败原因: BUILD Fail!
编译日志: D:\DevCoTools\LfcBpr\log.txt
```
