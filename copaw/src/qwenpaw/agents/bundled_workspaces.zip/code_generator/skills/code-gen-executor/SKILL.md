---
name: code-gen-executor
description: Execute the firmware code generation tool (ExcelConvert_3.1.exe) to generate firmware code from EDID/PCIID table files. Use this skill when the user asks to run code generation, execute the conversion tool, process EDID/PCIID tables, or generate firmware code. It calls scripts/start.cmd with TABLE_TYPE, RUN_PLATFORM, and FILE_PATH arguments, then parses result.json to report the outcome.
---

# Code Generation Executor Skill

## 概述

本 skill 执行代码生成工具 `scripts/start.cmd`，该工具调用 `ExcelConvert_3.1.exe` 根据表格文件（EDID/PCIID）生成对应的 firmware 代码。

## 依赖文件

`scripts/` 目录下必须存在以下文件才能正常运行：

| 文件 | 说明 |
|------|------|
| `start.cmd` | 启动脚本（入口） |
| `ExcelConvert_3.1.exe` | 核心代码生成工具 |
| `ec-input-path.ps1` | PowerShell 路径处理辅助脚本 |

## 输入参数

| 参数名 | 类型 | 描述 | 示例 |
|--------|------|------|------|
| TABLE_TYPE | 字符串 | 表格类型，支持 `EDID` 和 `PCIID` | `EDID` |
| RUN_PLATFORM | 字符串 | 平台类型，支持 `amd` 和 `intel` | `intel` |
| FILE_PATH | 字符串 | 表格文件的完整路径 | `D:\tables\edid_table.xlsx` |

> ⚠️ `start.cmd` 的入参顺序为：`TABLE_TYPE RUN_PLATFORM FILE_PATH`
>
> ⚠️ **编码约束（重要）：所有入参必须为 UTF-8 编码格式！**
> - `TABLE_TYPE`、`RUN_PLATFORM`、`FILE_PATH` 三个参数的值**必须使用 UTF-8 编码**传递
> - 脚本内部以 UTF-8 编码（`chcp 65001`）处理所有字符串和文件读写（含 `result.json`、路径暂存文件等）
> - 若入参使用非 UTF-8 编码（如 GBK、GB2312 等），可能导致含中文/特殊字符的 `FILE_PATH` 路径解析错误或乱码，造成代码生成失败
>
> ⚠️ **重要约束：EDID 表格只支持 intel 平台！** 如果 TABLE_TYPE=EDID 且 RUN_PLATFORM=amd，脚本会直接报错。
>
> ⚠️ FILE_PATH 如果包含空格，路径参数可以不使用引号（脚本内部通过 `ec-input-path.ps1` 自动拼接处理）。

## 工作流程

### 步骤 1：参数校验

> ⚠️ **每次执行都是全新的**，执行前**不需要**检查已有的 `result.json`，直接进行参数校验。

执行前校验：
- `TABLE_TYPE` 只能是 `EDID` 或 `PCIID`（不区分大小写）
- `RUN_PLATFORM` 只能是 `amd` 或 `intel`（不区分大小写）
- `EDID` 表格只支持 `intel` 平台
- `FILE_PATH` 不能为空，且文件必须存在

校验不通过时，直接返回错误信息，不调用脚本。

### 步骤 2：执行脚本

```batch
scripts\start.cmd <TABLE_TYPE> <RUN_PLATFORM> <FILE_PATH>
```

- 工作目录：`skills/code-gen-executor/scripts/`
- 脚本内部会：
  1. 通过 `ec-input-path.ps1` 处理文件路径
  2. 调用 `ExcelConvert_3.1.exe` 执行代码生成
  3. 将生成的代码文件复制到输入文件所在目录
  4. 生成 `result.json`

### 步骤 3：解析结果

执行完成后，读取 `scripts/result.json` 文件：

**成功时的 result.json 格式：**
```json
{"code": 0, "msg": "success"}
```

**失败时的 result.json 格式：**
```json
{"code": -1, "msg": "Invalid table type. Must be PCIID or EDID."}
```

或：
```json
{"code": 7, "msg": "Tool execution failed with exit code <N>."}
```

| code | 含义 |
|------|------|
| `0` | 成功 |
| `-1` | 参数校验失败 / 文件不存在 / ExcelConvert_3.1.exe 未找到 |
| `7` | 工具执行失败（ExcelConvert_3.1.exe 返回非零退出码） |

### 步骤 4：返回结果

- **成功**（code=0）：返回成功信息："ExcelConvert 代码生成成功"
- **失败**（code≠0）：仅返回失败原因（`msg` 字段内容），**不重试**

## 执行规则

1. **每次执行都是全新的** — 执行前不需要检查 `result.json`，直接开始参数校验和执行流程。上一次的执行结果不影响本次执行。
2. **不做重试** — 脚本执行失败后，直接返回失败原因，不重新执行
3. **诚实反馈** — 失败如实汇报原因，不修饰不隐瞒
4. **不要修改 result.json** — 只读取解析，不篡改内容

## 错误原因总结

| 触发条件 | 返回 msg |
|----------|----------|
| TABLE_TYPE 不是 EDID/PCIID | `Invalid table type. Must be PCIID or EDID.` |
| RUN_PLATFORM 不是 intel/amd | `Invalid platform. Must be intel or amd.` |
| EDID + amd 组合 | `EDID table processing supports intel platform only.` |
| 文件不存在 | `Input path does not exist (see third argument onward).` |
| ExcelConvert_3.1.exe 未找到 | `ExcelConvert_3.1.exe not found in the script directory.` |
| 工具运行失败 | `Tool execution failed with exit code <N>.` |

## 使用示例

### 示例 1：成功场景

**输入：**
> 帮我执行代码生成，EDID 表格，intel 平台，文件路径 D:\tables\monitor.xlsx

**执行：**
1. 校验参数：EDID ✓, intel ✓
2. 运行 `start.cmd EDID intel D:\tables\monitor.xlsx`
3. 读取 result.json → `{"code": 0, "msg": "success"}`
4. 返回成功信息

### 示例 2：EDID+amd 不支持

**输入：**
> 帮我执行代码生成，EDID 表格，amd 平台

**返回：** `EDID table processing supports intel platform only.`
