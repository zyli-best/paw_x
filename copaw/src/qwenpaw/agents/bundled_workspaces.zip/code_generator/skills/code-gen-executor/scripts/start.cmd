@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
cd /d "%~dp0"
set "EC_SCRIPT_DIR=%~dp0"

set "EXENAME=ExcelConvert_3.1.exe"
set "RESULT_FILE=%~dp0result.json"
set "EC_RESULT_JSON=%RESULT_FILE%"

if not exist "%EXENAME%" (
  set "EC_JSON_CODE=-1"
  set "EC_JSON_MSG=ExcelConvert_3.1.exe not found in the script directory."
  call :WriteJson
  exit 1
)

if "%~1"=="" goto ArgCountError
if "%~2"=="" goto ArgCountError
if "%~3"=="" goto ArgCountError

set "TABLE_TYPE=%~1"
set "RUN_PLATFORM=%~2"

rem Args from %3 onward are the input path (ec-input-path.ps1: sidecar + ConvertTo-EcWindowsPath when dot-sourced).
if /i not "!TABLE_TYPE!"=="PCIID" if /i not "!TABLE_TYPE!"=="EDID" (
  set "EC_JSON_CODE=-1"
  set "EC_JSON_MSG=Invalid table type. Must be PCIID or EDID."
  call :WriteJson
  exit 1
)

if /i not "!RUN_PLATFORM!"=="intel" if /i not "!RUN_PLATFORM!"=="amd" (
  set "EC_JSON_CODE=-1"
  set "EC_JSON_MSG=Invalid platform. Must be intel or amd."
  call :WriteJson
  exit 1
)

if /i "!TABLE_TYPE!"=="EDID" if /i not "!RUN_PLATFORM!"=="intel" (
  set "EC_JSON_CODE=-1"
  set "EC_JSON_MSG=EDID table processing supports intel platform only."
  call :WriteJson
  exit 1
)

set "EC_PATH_FILE=%TEMP%\ec_in_%RANDOM%.txt"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ec-input-path.ps1" %*
if errorlevel 1 (
  if defined EC_PATH_FILE if exist "!EC_PATH_FILE!" del /q "!EC_PATH_FILE!" 2>nul
  set "EC_JSON_CODE=-1"
  set "EC_JSON_MSG=Invalid file path (need type, platform, and path as third argument or more)."
  call :WriteJson
  exit 1
)

set "EC_TABLE_TYPE=!TABLE_TYPE!"
set "EC_RUN_PLATFORM=!RUN_PLATFORM!"
set "EC_EXENAME=!EXENAME!"

rem Validate path from sidecar; normalize Linux-style path to Windows here only.
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $e=[System.IO.File]::ReadAllText($env:EC_PATH_FILE,(New-Object System.Text.UTF8Encoding $false)).Trim(); if ($e.Length -eq 0) { exit 1 }; . (Join-Path $env:EC_SCRIPT_DIR 'ec-input-path.ps1'); $p = ConvertTo-EcWindowsPath $e; if ($null -eq $p -or $p.Length -eq 0) { exit 1 }; try { $p = [System.IO.Path]::GetFullPath($p) } catch { exit 1 }; if (-not (Test-Path -LiteralPath $p)) { exit 2 }; exit 0 } catch { exit 1 }"
set "PATH_EC=!ERRORLEVEL!"
if "!PATH_EC!"=="2" (
  if defined EC_PATH_FILE if exist "!EC_PATH_FILE!" del /q "!EC_PATH_FILE!" 2>nul
  set "EC_JSON_CODE=-1"
  set "EC_JSON_MSG=Input path does not exist (see third argument onward)."
  call :WriteJson
  exit 1
)
if not "!PATH_EC!"=="0" (
  if defined EC_PATH_FILE if exist "!EC_PATH_FILE!" del /q "!EC_PATH_FILE!" 2>nul
  set "EC_JSON_CODE=-1"
  set "EC_JSON_MSG=Path conversion failed or invalid file path."
  call :WriteJson
  exit 1
)

set "EC_WORK_DIR=%~dp0"
set "EC_SNAPSHOT=%TEMP%\ec_snap_%RANDOM%.txt"
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $d=$env:EC_WORK_DIR; if (-not (Test-Path -LiteralPath $d)) { exit 1 }; Get-ChildItem -LiteralPath $d -File | ForEach-Object { $_.Name + '|' + $_.Length + '|' + $_.LastWriteTimeUtc.Ticks } | Set-Content -LiteralPath $env:EC_SNAPSHOT -Encoding utf8 } catch { exit 1 }"
if errorlevel 1 (
  if defined EC_PATH_FILE if exist "!EC_PATH_FILE!" del /q "!EC_PATH_FILE!" 2>nul
  set "EC_JSON_CODE=-1"
  set "EC_JSON_MSG=Failed to prepare workspace snapshot."
  call :WriteJson
  exit 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $e=[System.IO.File]::ReadAllText($env:EC_PATH_FILE,(New-Object System.Text.UTF8Encoding $false)).Trim(); if ($e.Length -eq 0) { exit 1 }; . (Join-Path $env:EC_SCRIPT_DIR 'ec-input-path.ps1'); $p = ConvertTo-EcWindowsPath $e; if ($null -eq $p -or $p.Length -eq 0) { exit 1 }; try { $p = [System.IO.Path]::GetFullPath($p) } catch { exit 1 }; $work = $env:EC_WORK_DIR.TrimEnd([char]92); $exe = Join-Path $work $env:EC_EXENAME; if (-not (Test-Path -LiteralPath $exe)) { exit 1 }; & $exe $env:EC_TABLE_TYPE $env:EC_RUN_PLATFORM $p; exit $LASTEXITCODE } catch { exit 1 }"
set "TOOL_EXIT=!ERRORLEVEL!"
if not "!TOOL_EXIT!"=="0" (
  if defined EC_SNAPSHOT if exist "!EC_SNAPSHOT!" del /q "!EC_SNAPSHOT!" 2>nul
  if defined EC_PATH_FILE if exist "!EC_PATH_FILE!" del /q "!EC_PATH_FILE!" 2>nul
  set "EC_JSON_CODE=7"
  set "EC_JSON_MSG=Tool execution failed with exit code !TOOL_EXIT!."
  call :WriteJson
  exit 7
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $work = $env:EC_WORK_DIR.TrimEnd([char]92); $e=[System.IO.File]::ReadAllText($env:EC_PATH_FILE,(New-Object System.Text.UTF8Encoding $false)).Trim(); if ($e.Length -eq 0) { exit 0 }; . (Join-Path $env:EC_SCRIPT_DIR 'ec-input-path.ps1'); $p = ConvertTo-EcWindowsPath $e; if ($null -eq $p -or $p.Length -eq 0) { exit 0 }; try { $srcPath = [System.IO.Path]::GetFullPath($p) } catch { exit 1 }; $destRoot = [System.IO.Path]::GetDirectoryName($srcPath); if ([string]::IsNullOrEmpty($destRoot)) { exit 0 }; if (-not (Test-Path -LiteralPath $destRoot)) { exit 1 }; $snapFile = $env:EC_SNAPSHOT; $before = @{}; if (Test-Path -LiteralPath $snapFile) { Get-Content -LiteralPath $snapFile -Encoding utf8 | ForEach-Object { $a = $_.Split([char]124); if ($a.Length -ge 3) { $before[$a[0]] = @{ Len = [long]$a[1]; Ticks = [long]$a[2] } } } }; $exclude = [string[]]@('start.cmd','ExcelConvert_3.1.exe','result.json','ec-input-path.ps1'); Get-ChildItem -LiteralPath $work -File -ErrorAction Stop | ForEach-Object { $name = $_.Name; if ($exclude -contains $name) { return }; $curLen = $_.Length; $curTicks = $_.LastWriteTimeUtc.Ticks; $old = $before[$name]; $isNew = $null -eq $old; $isChanged = (-not $isNew) -and (($old.Len -ne $curLen) -or ($old.Ticks -ne $curTicks)); $target = Join-Path $destRoot $name; $destMissing = -not (Test-Path -LiteralPath $target); if ($isNew -or $isChanged -or $destMissing) { $srcFull = $_.FullName; Copy-Item -LiteralPath $srcFull -Destination $target -Force; $srcR = [System.IO.Path]::GetFullPath($srcFull); $dstR = [System.IO.Path]::GetFullPath($target); if (-not [string]::Equals($srcR, $dstR, [StringComparison]::OrdinalIgnoreCase)) { Remove-Item -LiteralPath $srcFull -Force } } }; Remove-Item -LiteralPath $snapFile -ErrorAction SilentlyContinue } catch { exit 1 }"
if errorlevel 1 (
  if defined EC_PATH_FILE if exist "!EC_PATH_FILE!" del /q "!EC_PATH_FILE!" 2>nul
  set "EC_JSON_CODE=-1"
  set "EC_JSON_MSG=Failed to copy tool outputs to input directory."
  call :WriteJson
  exit 1
)

if defined EC_PATH_FILE if exist "!EC_PATH_FILE!" del /q "!EC_PATH_FILE!" 2>nul
set "EC_JSON_CODE=0"
set "EC_JSON_MSG=success"
call :WriteJson
exit 0

:ArgCountError
set "EC_JSON_CODE=-1"
set "EC_JSON_MSG=Invalid argument count. Expected: table type, platform, file path (path may be several unquoted tokens if it contains spaces)."
call :WriteJson
exit 1

:WriteJson
powershell -NoProfile -ExecutionPolicy Bypass -Command "$code=[int]$env:EC_JSON_CODE; $msg=$env:EC_JSON_MSG; if ($null -eq $msg) { $msg='' }; $p=$env:EC_RESULT_JSON; if ([string]::IsNullOrEmpty($p)) { $p=Join-Path (Get-Location).Path 'result.json' }; $obj=[ordered]@{ code=$code; msg=$msg }; $json=($obj | ConvertTo-Json -Compress -Depth 5); $utf8=New-Object System.Text.UTF8Encoding $false; [System.IO.File]::WriteAllText($p, $json, $utf8)"
exit /b 0
