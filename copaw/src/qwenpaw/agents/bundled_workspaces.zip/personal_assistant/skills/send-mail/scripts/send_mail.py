#!/usr/bin/env python3
"""
Send email via MCP client (mcp-client.exe).

Usage:
    python send_mail.py --recipient "user@example.com" --subject "Subject" --body "<html>...</html>"

Fixed MCP parameters:
    --transport "streamable-http"
    --url "http://10.159.252.56:10001/mcp"
    --action call-tool
    --name send_mail

On failure: prints error and exits with code 1. No retry.
"""

import argparse
import subprocess
import sys
import os
import tempfile


# Path to mcp-client.exe (located next to this script)
MCP_CLIENT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mcp-client.exe")

# Fixed MCP parameters
MCP_TRANSPORT = "streamable-http"
MCP_URL = "http://10.159.252.56:10001/mcp"
MCP_ACTION = "call-tool"
MCP_TOOL_NAME = "send_mail"


def send_mail(recipient: str, subject: str, body: str) -> tuple[bool, str]:
    """
    Send an email via mcp-client.exe.

    Returns:
        (success: bool, message: str)
    """
    # Check if mcp-client.exe exists
    if not os.path.isfile(MCP_CLIENT):
        return False, f"mcp-client.exe not found at: {MCP_CLIENT}"

    # Build command
    cmd = [
        MCP_CLIENT,
        "--transport", MCP_TRANSPORT,
        "--url", MCP_URL,
        "--action", MCP_ACTION,
        "--name", MCP_TOOL_NAME,
        "--arg", f"recipient={recipient}",
        "--arg", f"subject={subject}",
        "--arg", f"body={body}",
    ]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,
            encoding="utf-8",
            errors="replace",
        )

        stdout = result.stdout.strip() if result.stdout else ""
        stderr = result.stderr.strip() if result.stderr else ""

        if result.returncode == 0:
            return True, stdout or "发送成功"
        else:
            error_msg = stderr or stdout or f"Exit code: {result.returncode}"
            return False, error_msg

    except subprocess.TimeoutExpired:
        return False, "发送超时（60秒）"
    except FileNotFoundError:
        return False, f"mcp-client.exe not found at: {MCP_CLIENT}"
    except Exception as e:
        return False, f"发送异常: {str(e)}"


def main():
    parser = argparse.ArgumentParser(
        description="Send email via MCP client (mcp-client.exe)"
    )
    parser.add_argument(
        "--recipient", required=True,
        help="Recipient email address"
    )
    parser.add_argument(
        "--subject", required=True,
        help="Email subject line"
    )
    parser.add_argument(
        "--body", required=True,
        help="Email body in HTML format"
    )

    args = parser.parse_args()

    # Basic validation
    if "@" not in args.recipient:
        print(f"发送失败: 无效的收件人邮箱地址: {args.recipient}", file=sys.stderr)
        sys.exit(1)

    success, message = send_mail(args.recipient, args.subject, args.body)

    if success:
        print(message)
        sys.exit(0)
    else:
        print(f"发送失败: {message}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()