---
name: send-mail
description: Send professional HTML emails via MCP email service. Use this skill whenever the user wants to send an email, notify someone about task completion, deliver reports, or any email communication. Triggers on phrases like "send email", "发邮件", "通知", "邮件发送", "send notification", or when the user provides recipient/subject/body for email delivery.
---

# Send Mail

Send professional HTML emails through the MCP email service using `mcp-client.exe`.

## When to Use

Use this skill whenever the user needs to:
- Send an email notification
- Notify someone about task completion
- Deliver reports, documents, or any email communication
- Any request involving email sending

## Workflow

### Step 1: Gather Required Information

You need three pieces of information from the user:

| Parameter | Required | Description |
|-----------|:--------:|-------------|
| `recipient` | ✅ | Recipient email address |
| `subject` | ✅ | Email subject line |
| `body context` | ✅ | What the email is about — task name, deliverables, status, etc. |

If any parameter is missing, ask the user before proceeding.

### Step 2: Generate HTML Email Body

**Read `references/email_template.md`** for the complete HTML email template specification. Follow ALL rules strictly:

**Layout & Compatibility:**
- Use **inline styles only** — all styles via `style=""` attribute, no `<style>` tags or external CSS
- **Table-based layout** — wrap content in `<table>`, 600px width, centered
- Safe font stack: `font-family: 'Microsoft YaHei', '微软雅黑', Arial, Helvetica, sans-serif`
- Use `line-height` and `padding` for spacing, NOT `margin`
- Avoid: `<div>` layout, CSS float/flex/grid, external fonts, background images

**Content Structure:**
- English salutation: `Dear Mr./Ms./Dr. [Last Name],`
  - Extract last name from full name if provided
  - If last name unknown: `Dear Sir or Madam,`
- Main body: concisely state task completion
- Deliverable info (if applicable): unordered list with **name**, **status**, **location**, **version**, **time**
- Status styling: success → bright red (`color: #ff2d2d`), failure → gray (`color: #999999`)
- Keep it concise — notify completion only, no process details or next steps

### Step 3: Send the Email

Run the send script from the skill's scripts directory:

```bash
python "<skill_dir>/scripts/send_mail.py" --recipient "<email>" --subject "<subject>" --body "<html_body>"
```

The script calls `mcp-client.exe` with these fixed parameters:
- `--transport "streamable-http"`
- `--url "http://10.159.252.56:10001/mcp"`
- `--action call-tool`
- `--name send_mail`

### Step 4: Report Result

- **Success**: Tell the user "✅ 邮件发送成功！"
- **Failure**: Tell the user the exact error message returned by the script. **Do NOT retry.**

## Important Rules

- **Never retry** on failure — just report the error and stop
- **Never modify** the user's intended content or recipient
- **Never send** to recipients not explicitly approved by the user
- Keep all information confidential — do not expose email content to unauthorized parties